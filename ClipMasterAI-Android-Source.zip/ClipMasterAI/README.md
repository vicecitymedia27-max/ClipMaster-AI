# ClipMaster AI — Android starter

This is a free Android Studio starter project for ClipMaster AI.

## Current starter features
- Choose a local video using Android's system file picker.
- Enter a start time in seconds.
- Export a 30-second MP4 segment using AndroidX Media3 Transformer.
- Paste a YouTube URL to open it in the YouTube app/browser.

## Important YouTube limitation
This app intentionally does **not** download or extract arbitrary YouTube streams. YouTube's official APIs do not provide a general-purpose video-download endpoint, and downloading videos without permission may violate YouTube's terms or copyright. Use videos you own, have permission to edit, or files you are otherwise authorized to use. For your own YouTube uploads, download them through YouTube's official creator tools, then import the file here.

## Build a debug APK for free
1. Install Android Studio on a computer (Windows/macOS/Linux) from https://developer.android.com/studio
2. Open this `ClipMasterAI` folder in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Notes / next development steps
- This starter exports a 30-second segment but does not yet add a vertical 9:16 crop, subtitles, AI highlight detection, or voice-over.
- 1080p output depends on source resolution and device/Media3 encoding support. A 720p source cannot become true 1080p detail simply by exporting at a larger size.
- A computer with Android Studio is needed to compile/sign the APK. This workspace can provide the source project, but does not have an Android SDK build environment.
