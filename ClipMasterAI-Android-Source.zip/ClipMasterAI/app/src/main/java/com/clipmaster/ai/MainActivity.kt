package com.clipmaster.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private var selectedVideo: Uri? = null
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            selectedVideo = uri
            status.text = "Video selected. Choose a start time and export."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            gravity = Gravity.TOP
            setBackgroundColor(0xFF10131B.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 12)
        }
        val title = label("ClipMaster AI", 28f)
        val subtitle = label("Make a 30-second clip • 1080p export", 15f)
        val pick = Button(this).apply { text = "Choose video from phone"; setOnClickListener { pickVideo.launch(arrayOf("video/*")) } }
        startInput = EditText(this).apply {
            hint = "Start time in seconds (e.g. 45)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("0")
        }
        val export = Button(this).apply { text = "Export 30-second clip"; setOnClickListener { exportClip() } }
        val yt = EditText(this).apply { hint = "Paste YouTube URL (opens YouTube)"; setSingleLine(true) }
        val openYt = Button(this).apply {
            text = "Open YouTube link"
            setOnClickListener {
                val raw = yt.text.toString().trim()
                if (raw.startsWith("https://www.youtube.com/") || raw.startsWith("https://youtu.be/")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(raw)))
                    status.text = "Open the video in YouTube. Import a video file only if you own it or have permission."
                } else status.text = "Enter a valid HTTPS YouTube link."
            }
        }
        status = label("Ready. Select a video you own or have permission to edit.", 14f)
        layout.addView(title); layout.addView(subtitle); layout.addView(pick)
        layout.addView(startInput); layout.addView(export); layout.addView(yt)
        layout.addView(openYt); layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun exportClip() {
        val uri = selectedVideo ?: run { status.text = "Please choose a video first."; return }
        val startMs = (startInput.text.toString().toLongOrNull() ?: 0L).coerceAtLeast(0L) * 1000L
        val out = File(getExternalFilesDir(null), "ClipMaster_${System.currentTimeMillis()}.mp4")
        status.text = "Exporting… keep the app open."
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            .setRemoveAudio(false)
            .build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                status.text = "Export complete: ${out.absolutePath}"
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                status.text = "Export failed: ${exportException.message}"
            }
        }
        // Media3 clipping is represented by a clipped MediaItem.
        val clipped = MediaItem.Builder().setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(startMs + 30_000L)
                    .build()
            ).build()
        val clipEdited = EditedMediaItem.Builder(clipped).build()
        transformer = Transformer.Builder(this).addListener(listener).build()
        transformer?.start(clipEdited, out.absolutePath)
    }
}
